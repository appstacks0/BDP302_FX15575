function test(){
    var num = 12;
    if(num < 10)
        console.log(num + " is less than 10");
    else
        console.log(num + " is not less than 10");
}

test()